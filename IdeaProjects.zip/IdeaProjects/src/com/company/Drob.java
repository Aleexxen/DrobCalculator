package com.company;

public class Drob {

    int num;
    int denom;

    public  Drob(int num, int denom){

        this.num = num;
        this.denom = denom;

    }

    public int getNum(){
        return num;
    }

    public int getDenom(){

        return denom;
    }

    public void setNum(int num){

        this.num = num;
    }

    public void setDenom(int denom){

        this.denom = denom;
    }

}
